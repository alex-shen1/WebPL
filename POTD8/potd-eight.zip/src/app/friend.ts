export class Friend {
  name: string;
  email: string;

  constructor(nm:string, em:string){
    this.name = nm;
    this.email = em;
  }
}
